{-# LANGUAGE OverloadedStrings, TypeFamilies, QuasiQuotes,
             TemplateHaskell, GADTs, FlexibleInstances,
             MultiParamTypeClasses, DeriveDataTypeable,
             GeneralizedNewtypeDeriving, ViewPatterns, EmptyDataDecls #-}
import Yesod
import Database.Persist.Postgresql
import Data.Text
import Control.Monad.Logger (runStdoutLoggingT)
             
data Pagina = Pagina{connPool :: ConnectionPool}

instance Yesod Pagina

share [mkPersist sqlSettings, mkMigrate "migrateAll"] [persistLowerCase|
Clientes json
   nome Text
   deriving Show
|]

mkYesod "Pagina" [parseRoutes|
-- /cadastro UserR POST OPTIONS !Colocar todos os recursos em uma única URI
/ ChomeR GET
/cliente/cadastrar CcadastroR POST
/cliente/mostrarTodos CmostrarTodos OPTIONS GET 
/cliente/alterar/#ClientesId Calterar OPTIONS PUT
/cliente/deletar/#ClientesId Cdeletar OPTIONS DELETE

-- /cadastro/action/#ClientesId ActionR GET PUT POST DELETE
|]

instance YesodPersist Pagina where
   type YesodPersistBackend Pagina = SqlBackend
   runDB f = do
       master <- getYesod
       let pool = connPool master
       runSqlPool f pool
------------------------------------------------------

getChomeR :: Handler Html
getChomeR = defaultLayout $ do
    [whamlet| <h1> Ola Mundo|]

optionsCcadastroR :: ClientesId -> Handler ()
optionsCcadastroR cid = do
    addHeader "Access-Control-Allow-Origin" "*"
    addHeader "Access-Control-Allow-Methods" "POST, OPTIONS"
    
postCcadastroR :: Handler ()
postCcadastroR = do
    addHeader "Access-Control-Allow-Origin" "*"
    cliente <- requireJsonBody :: Handler Clientes
    runDB $ insert cliente
    sendResponse (object [pack "resp" .= pack "CREATED"])

optionsCmostrarTodos :: Handler ()
optionsCmostrarTodos = do
    addHeader "Access-Control-Allow-Origin" "*"
    addHeader "Access-Control-Allow-Methods" "GET, OPTIONS"
    
getCmostrarTodos :: Handler ()
getCmostrarTodos = do
    addHeader "Access-Control-Allow-Origin" "*"
    clientes <- runDB $ selectList [] [Asc ClientesNome]
    sendResponse (object["clientes" .= fmap toJSON clientes])

optionsCalterar :: ClientesId -> Handler ()
optionsCalterar cid = do
    addHeader "Access-Control-Allow-Origin" "*"
    addHeader "Access-Control-Allow-Methods" "PUT, OPTIONS"

putCalterar :: ClientesId -> Handler ()
putCalterar cid = do
    addHeader "Access-Control-Allow-Origin" "*"
    cliente <- requireJsonBody :: Handler Clientes
    runDB $ update cid [ClientesNome =. clientesNome cliente ]
    sendResponse (object [pack "resp" .= pack "Changed"])
    
optionsCdeletar :: ClientesId -> Handler ()
optionsCdeletar cid = do
    addHeader "Access-Control-Allow-Origin" "*"
    addHeader "Access-Control-Allow-Methods" "DELETE, OPTIONS"

deleteCdeletar :: ClientesId -> Handler ()
deleteCdeletar cid = do
    addHeader "Access-Control-Allow-Origin" "*"
    runDB $ delete cid
    sendResponse (object [pack "resp".= pack "Deleted"])
    

{-
postUserR :: Handler ()
postUserR = do
    clientes <- requireJsonBody :: Handler Clientes
    runDB $ insert clientes
    sendResponse (object [pack "resp" .= pack "CREATED"])
-}

{-
getActionR :: ClientesId -> Handler ()
getActionR cid = do
    cliente <- runDB $ get404 cid
    sendResponse $ toJSON cliente

putActionR :: ClientesId -> Handler ()
putActionR cid = do
    cliente <- requireJsonBody :: Handler Clientes
    runDB $ update cid [ClientesNome =. clientesNome cliente]
    sendResponse (object [pack "resp" .= pack "UPDATE"])


optionsUserR :: Handler ()
optionsUserR = addHeader "Access-Control-Allow-Methods" "POST, OPTIONS"
-}

connStr = "dbname=dd9en8l5q4hh2a host=ec2-107-21-219-201.compute-1.amazonaws.com user=kpuwtbqndoeyqb password=aCROh525uugAWF1l7kahlNN3E0 port=5432"
-- connStr = "dbname=dd9en8l5q4hh2a host=ec2-107-21-219-201.compute-1.amazonaws.com user=kpuwtbqndoeyqb password=aCROh525uugAWF1l7kahlNN3E0 port=5432"

main::IO()
main = runStdoutLoggingT $ withPostgresqlPool connStr 10 $ \pool -> liftIO $ do 
       runSqlPersistMPool (runMigration migrateAll) pool
       warp 8080 (Pagina pool)
       
       